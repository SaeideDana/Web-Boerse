'use strict';

window.addEventListener('DOMContentLoaded', function () {
    const buyButton = document.getElementById('buy-button');
    const sellButton = document.getElementById('sell-button');
    const stockSelect = document.getElementById('stock-select');
    const quantityInput = document.getElementById('quantity');

    buyButton.addEventListener('click', () => handleStockAction(stockSelect.value, parseInt(quantityInput.value) || 0));
    sellButton.addEventListener('click', () => handleStockAction(stockSelect.value, -(parseInt(quantityInput.value) || 0)));

    function handleStockAction(stockName, quantity) {
        postData(stockName, quantity);
    }

    function postData(stockName, quantity) {
        const url = '/api/umsaetze';
        const data = {
            'aktie': { 'name': stockName },
            'anzahl': quantity
        };

        fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        throw new Error(`Error: ${response.status} - ${text}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                console.log('Erfolg:', data);
            })
            .catch(error => {
                console.error('Fehler beim Senden der Daten:', error);
                // Fehlerbehandlung
            });
        getUser();
    }
});
