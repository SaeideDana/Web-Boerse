document.addEventListener('DOMContentLoaded', function() {
    // Fiktive Daten
    const stockData = {
        'AMD': [50, 51, 52, 53, 54],
        'Intel': [30, 31, 32, 33, 34],
        'Microsoft': [100, 102, 104, 106, 108]
    };
    const labels = ['9:00', '10:00', '11:00', '12:00', '13:00'];


    // Verarbeiten der Daten für die Verwendung mit Chart.js
    const datasets = Object.keys(stockData).map((key, index) => {
        return {
            label: key,
            data: stockData[key],
            backgroundColor: getRandomColor(), // Funktion um eine zufällige Farbe zu generieren
            order: index
        };
    });

    // Konfiguration des Graphen
    const config = {
        type: 'bar', // Änderung zu 'bar' für ein Balkendiagramm
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    };

    // Erstellen des Graphen
    new Chart(document.getElementById('stockChart'), config);
});

// Funktion zur Erzeugung einer zufälligen Farbe
function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
