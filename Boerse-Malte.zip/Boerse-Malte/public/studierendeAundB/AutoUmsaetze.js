'use strict';

const stockLimits = {
    'AMD': { buyAt: 50, sellAt: 70 },
    'Intel': { buyAt: 30, sellAt: 50 },
    'Microsoft': { buyAt: 100, sellAt: 150 }
    // Fügen Sie hier weitere Aktien und deren Grenzen hinzu
};

document.addEventListener('DOMContentLoaded', function() {
    function checkStockPricesAndTrade() {
        fetchStockPrices().then(prices => {
            for (const [stockName, price] of Object.entries(prices)) {
                if (price < stockLimits[stockName].buyAt) {
                    console.log(`Kaufe ${stockName}, da der Preis unter ${stockLimits[stockName].buyAt} gefallen ist: ${price}`);
                    performTrade(stockName, 'buy', calculateQuantity(stockName));
                } else if (price > stockLimits[stockName].sellAt) {
                    console.log(`Verkaufe ${stockName}, da der Preis über ${stockLimits[stockName].sellAt} gestiegen ist: ${price}`);
                    performTrade(stockName, 'sell', calculateQuantity(stockName));
                }
            }
        });
    }

    function performTrade(stockName, action, quantity) {
        const apiUrl = '/api/umsaetze ';
        const endpoint = '/orders';
        const apiKey = 'IHR_API_SCHLUESSEL';

        const data = {
            symbol: stockName,
            type: action,
            quantity: quantity
        };

        fetch(apiUrl + endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + apiKey
            },
            body: JSON.stringify(data)
        })
            .then(response => response.json())
            .then(data => {
                console.log('Handelsergebnis:', data);
                document.getElementById('status').innerHTML += `<p>${action === 'buy' ? 'Gekauft' : 'Verkauft'} ${quantity} Stück ${stockName}.</p>`;
            })
            .catch(error => {
                console.error('Fehler beim Handel:', error);
                document.getElementById('status').innerHTML += `<p>Fehler beim Handeln von ${stockName}: ${error}</p>`;
            });
    }
//  Funktion zum Aktualisieren des Handelsstatus
    function updateTradeStatus(stockName, action, quantity) {
        const statusDiv = document.getElementById('status');
        const message = `<p>${action === 'buy' ? 'Gekauft' : 'Verkauft'}: ${quantity} Anteile von ${stockName}.</p>`;
        statusDiv.innerHTML += message; // Fügt die Nachricht zum Status-Div hinzu
    }
    function calculateQuantity(stockName) {
        // Berechnen Sie hier die Anzahl der Aktien, die gehandelt werden sollen
        // Diese Funktion kann angepasst werden, um die Logik für die Berechnung der Menge zu enthalten
        return 10; // Beispiel: Eine feste Zahl
    }

    function fetchStockPrices() {
        return Promise.resolve({
            'AMD': 55,
            'Intel': 35,
            'Microsoft': 120
        });
    }

    setInterval(checkStockPricesAndTrade, 1000); // Überprüft alle 1 Minuten
});
